package com.culture.client.api.service;

import java.util.List;

import com.culture.client.api.vo.ApiMovieVO;

public interface ApiMovieService {

	List<ApiMovieVO> getNowPlayingMovies();
	ApiMovieVO getMovieDetail(String id);
	List<ApiMovieVO> searchMovie(String searchTitle);



}
