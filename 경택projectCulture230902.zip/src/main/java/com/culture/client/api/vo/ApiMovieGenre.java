package com.culture.client.api.vo;

import lombok.Data;

@Data
public class ApiMovieGenre {
    private int id;
    private String name;

}
