package com.culture.client.user.dao;

import org.apache.ibatis.annotations.Mapper;

import com.culture.client.user.vo.UserVO;

@Mapper
public interface UserDAO {
	public UserVO login(UserVO uvo);
	public UserVO signUp(UserVO uvo);
	public int idChk(UserVO uvo);
}