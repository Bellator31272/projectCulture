package com.culture.client.user.service;

import com.culture.client.user.vo.UserVO;

public interface UserService {

	public UserVO login(UserVO uvo);
	public UserVO signUp(UserVO uvo);
	public int idChk(String uvo);
	public int idChk(UserVO uvo);
}